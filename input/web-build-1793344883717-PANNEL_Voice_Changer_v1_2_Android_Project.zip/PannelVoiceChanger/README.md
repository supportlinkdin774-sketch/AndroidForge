# PANNEL Voice Changer — Android Studio project (v1.1)

A dark gaming-style Android microphone monitor demo with Clean, Bright, Deep, Robot and Monster processing presets.

## Build and install
1. Open this folder in Android Studio.
2. Allow Gradle sync to finish.
3. Connect your Android phone with USB debugging enabled.
4. Press Run and grant microphone permission.

## Honest feature status
- Included: gaming-style interface, in-app quick controls, local microphone effects monitor.
- Not included: a true system floating overlay, system virtual microphone, or injection of modified audio into Free Fire.
- Android's normal app sandbox does not let an ordinary app replace another app's microphone source. Xiaomi/HyperOS would need to provide system-level support for that.
- The Bright/Deep presets are simple tone-level demonstrations, not professional pitch shifting. Bluetooth can add latency.
