package com.pannel.voicechanger

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import android.media.*
import android.net.Uri
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread
import kotlin.math.PI
import kotlin.math.sin
import kotlin.math.tanh

class MainActivity : Activity() {
    private val running = AtomicBoolean(false)
    private var recorder: AudioRecord? = null
    private var player: AudioTrack? = null
    private var musicPlayer: MediaPlayer? = null
    private var effect = "Clean"
    private lateinit var status: TextView
    private lateinit var startButton: Button
    private lateinit var effectInfo: TextView
    private val sampleRate = 44100
    private val bg = Color.rgb(8, 12, 25)
    private val panel = Color.rgb(19, 27, 47)
    private val accent = Color.rgb(0, 225, 190)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 24)
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this).apply { addView(page) }

        val brand = label("PANNEL", 13f, accent, true).apply { letterSpacing = .22f }
        page.addView(brand)
        page.addView(label("ALL AUDIO MIC", 29f, Color.WHITE, true))
        page.addView(label("GAMING MUSIC + MIC DEMO  /  V1.3", 11f, Color.LTGRAY, false))

        val hero = card()
        hero.addView(label("●  LIVE AUDIO CONSOLE", 13f, accent, true))
        status = label("READY  •  Select a voice effect", 14f, Color.WHITE, true)
        status.setPadding(0, 12, 0, 4)
        hero.addView(status)
        effectInfo = label("Microphone monitor is off", 12f, Color.LTGRAY, false)
        hero.addView(effectInfo)
        page.addView(hero)

        page.addView(sectionTitleView("VOICE PRESETS"))
        val grid = GridLayout(this).apply { columnCount = 2 }
        listOf(
            "Clean" to "Natural",
            "Female • Bright" to "Bright tone",
            "Male • Deep" to "Deep tone",
            "Robot" to "Synthetic",
            "Monster" to "Distortion"
        ).forEach { (name, desc) ->
            val b = Button(this).apply {
                text = "$name\\n$desc"
                textSize = 13f
                isAllCaps = false
                setTextColor(Color.WHITE)
                setBackgroundColor(panel)
                setOnClickListener {
                    effect = name
                    status.text = "PRESET SELECTED  •  $name"
                    effectInfo.text = if (running.get()) "Live monitor running with $name" else "Ready to monitor with $name"
                }
            }
            val params = GridLayout.LayoutParams().apply {
                width = 0
                height = dp(68)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(4), dp(4), dp(4), dp(4))
            }
            grid.addView(b, params)
        }
        page.addView(grid)

        page.addView(sectionTitleView("MUSIC PLAYER"))
        val musicCard = card()
        musicCard.addView(label("Play a song from your phone", 14f, Color.WHITE, true))
        val chooseSong = Button(this).apply {
            text = "♫  CHOOSE SONG"
            isAllCaps = false
            setOnClickListener {
                val intent = android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(android.content.Intent.CATEGORY_OPENABLE)
                    type = "audio/*"
                }
                startActivityForResult(intent, 21)
            }
        }
        musicCard.addView(chooseSong, LinearLayout.LayoutParams(-1, dp(52)))
        val musicControls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val playMusic = Button(this).apply { text = "▶ PLAY"; isAllCaps = false; setOnClickListener { try { musicPlayer?.start(); status.text = "MUSIC PLAYING • PHONE OUTPUT" } catch (_: Exception) { status.text = "CHOOSE A SONG FIRST" } } }
        val pauseMusic = Button(this).apply { text = "Ⅱ PAUSE"; isAllCaps = false; setOnClickListener { musicPlayer?.pause() } }
        musicControls.addView(playMusic, LinearLayout.LayoutParams(0, dp(48), 1f))
        musicControls.addView(pauseMusic, LinearLayout.LayoutParams(0, dp(48), 1f))
        musicCard.addView(musicControls)
        musicCard.addView(label("Music plays through the phone speaker/headphone. Free Fire microphone routing is not provided by Android for normal apps.", 11f, Color.LTGRAY, false))
        page.addView(musicCard)

        page.addView(sectionTitleView("QUICK CONTROL"))
        val controls = card()
        startButton = Button(this).apply {
            text = "▶  START LIVE MONITOR"
            isAllCaps = false
            textSize = 15f
            setOnClickListener {
                if (running.get()) stopAudio() else if (
                    checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7)
                } else startAudio()
            }
        }
        controls.addView(startButton, LinearLayout.LayoutParams(-1, dp(56)))
        val quick = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val stop = Button(this).apply {
            text = "■ STOP"
            isAllCaps = false
            setOnClickListener { if (running.get()) stopAudio() }
        }
        val reset = Button(this).apply {
            text = "↺ RESET EFFECT"
            isAllCaps = false
            setOnClickListener {
                effect = "Clean"
                status.text = "PRESET SELECTED  •  Clean"
                effectInfo.text = "Clean voice selected"
            }
        }
        quick.addView(stop, LinearLayout.LayoutParams(0, dp(48), 1f))
        quick.addView(reset, LinearLayout.LayoutParams(0, dp(48), 1f))
        controls.addView(quick)
        page.addView(controls)

        page.addView(sectionTitleView("GAMING SETUP"))
        val tips = card()
        tips.addView(label("🎧  Use wired or Bluetooth headphones", 13f, Color.WHITE, true))
        tips.addView(label("Keep the phone volume low to prevent echo. Bluetooth may introduce delay.", 12f, Color.LTGRAY, false))
        tips.addView(label("\\nFLOATING CONTROLS", 13f, accent, true))
        tips.addView(label("This version includes an in-app quick-control panel styled for gaming. It does not yet draw over Free Fire.", 12f, Color.LTGRAY, false))
        page.addView(tips)

        val warning = label(
            "\\nANDROID LIMITATION\\nAn ordinary Android app cannot replace Free Fire's microphone with a virtual microphone. This demo changes audio and plays it back locally; the effects are not sent into the game's mic. System-level routing needs Xiaomi/HyperOS support or privileged access.",
            11f, Color.rgb(190, 198, 214), false
        )
        warning.setPadding(dp(5), dp(12), dp(5), dp(12))
        page.addView(warning)
        setContentView(scroll)
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 21 && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            try {
                musicPlayer?.release()
                musicPlayer = MediaPlayer().apply {
                    setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                    setDataSource(this@MainActivity, uri)
                    setOnPreparedListener { it.start(); status.text = "MUSIC PLAYING • PHONE OUTPUT" }
                    setOnErrorListener { _, _, _ -> status.text = "MUSIC FILE ERROR"; true }
                    prepareAsync()
                }
                status.text = "LOADING MUSIC…"
            } catch (e: Exception) { status.text = "MUSIC ERROR • ${e.javaClass.simpleName}" }
        }
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(14), dp(15), dp(14))
        setBackgroundColor(panel)
    }

    private fun sectionTitle(s: String) {
        // helper is intentionally called through addSection below
    }

    private fun sectionTitleView(s: String) = label(s, 13f, accent, true).apply {
        setPadding(dp(2), dp(18), 0, dp(7))
    }

    private fun label(s: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(null, Typeface.BOLD)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun startAudio() {
        try {
            val minIn = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val minOut = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val size = maxOf(minIn, minOut, 4096)
            recorder = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, sampleRate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, size)
            player = AudioTrack(AudioManager.STREAM_MUSIC, sampleRate, AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT, size, AudioTrack.MODE_STREAM)
            if (recorder?.state != AudioRecord.STATE_INITIALIZED || player?.state != AudioTrack.STATE_INITIALIZED) {
                status.text = "AUDIO DEVICE ERROR"
                stopAudio()
                return
            }
            running.set(true)
            recorder?.startRecording()
            player?.play()
            startButton.text = "■  STOP LIVE MONITOR"
            status.text = "● LIVE  •  $effect"
            effectInfo.text = "Listening and playing processed audio locally"
            thread(name = "PannelAudio") {
                val input = ShortArray(1024)
                val output = ShortArray(1024)
                var phase = 0.0
                while (running.get()) {
                    val n = recorder?.read(input, 0, input.size) ?: -1
                    if (n > 0) {
                        for (i in 0 until n) {
                            val x = input[i].toDouble() / 32768.0
                            val y = when (effect) {
                                "Robot" -> {
                                    phase += 2.0 * PI * 35.0 / sampleRate
                                    if (phase > 2.0 * PI) phase -= 2.0 * PI
                                    x * sin(phase) * 1.8
                                }
                                "Monster" -> tanh(x * 4.0) * 1.25
                                "Female • Bright" -> x * 1.18
                                "Male • Deep" -> x * 0.82
                                else -> x
                            }
                            output[i] = (y.coerceIn(-1.0, 1.0) * 32767.0).toInt().toShort()
                        }
                        player?.write(output, 0, n)
                    }
                }
            }
        } catch (e: Exception) {
            status.text = "ERROR  •  ${e.javaClass.simpleName}"
            stopAudio()
        }
    }

    private fun stopAudio() {
        running.set(false)
        try { recorder?.stop() } catch (_: Exception) {}
        try { player?.pause(); player?.flush(); player?.stop() } catch (_: Exception) {}
        recorder?.release(); player?.release()
        recorder = null; player = null
        if (::startButton.isInitialized) startButton.text = "▶  START LIVE MONITOR"
        if (::status.isInitialized) status.text = "STOPPED"
        if (::effectInfo.isInitialized) effectInfo.text = "Microphone monitor is off"
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 7 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startAudio()
        else status.text = "MICROPHONE PERMISSION REQUIRED"
    }

    override fun onDestroy() { stopAudio(); musicPlayer?.release(); musicPlayer = null; super.onDestroy() }
}
