package com.ffvoicebridge;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int RATE = 44100;
    private volatile boolean micOn = false;
    private AudioRecord recorder;
    private AudioTrack monitorTrack;
    private Thread micThread;
    private TextView status;
    private int pitchRate = RATE;
    private AudioTrack effectTrack;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setBackgroundColor(0xFF07111F);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(22, 24, 22, 28);
        scroll.addView(root);

        TextView title = label("FF VOICE BRIDGE", 27, 0xFF35D7FF);
        title.setGravity(Gravity.CENTER);
        root.addView(title, params(-1, 58));
        TextView subtitle = label("VOICE LAB  •  SOUNDBOARD  •  MIC TEST", 12, 0xFFB9C9D8);
        subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle, params(-1, 32));

        status = label("● READY", 15, 0xFF75F0A8);
        status.setGravity(Gravity.CENTER);
        root.addView(status, params(-1, 46));

        section(root, "LIVE MIC MONITOR");
        addButton(root, "START MIC MONITOR", 0xFF126B60, v -> startMic());
        addButton(root, "STOP MIC", 0xFF713A48, v -> stopMic());

        section(root, "VOICE EFFECT PRESETS");
        addButton(root, "NORMAL VOICE", 0xFF173A58, v -> setPitch(RATE, "NORMAL"));
        addButton(root, "DEEP VOICE", 0xFF173A58, v -> setPitch(33075, "DEEP"));
        addButton(root, "CHIPMUNK VOICE", 0xFF173A58, v -> setPitch(55125, "HIGH"));
        addButton(root, "ROBOT / RADIO TEST", 0xFF173A58, v -> setPitch(44100, "ROBOT TEST"));

        section(root, "SOUNDBOARD");
        addButton(root, "AIR HORN", 0xFF6A4A18, v -> playToneSequence(new int[]{440,660,880}, 160));
        addButton(root, "LASER", 0xFF6A4A18, v -> playToneSequence(new int[]{1200,900,600,300}, 90));
        addButton(root, "ALERT BEEP", 0xFF6A4A18, v -> playToneSequence(new int[]{880,880,880}, 100));
        addButton(root, "STOP SOUND", 0xFF713A48, v -> stopEffect());

        section(root, "IMPORTANT LIMIT");
        TextView warning = label(
            "This app can play effects and monitor/process your mic locally. Android normally does NOT let a regular app inject its audio into Free Fire's microphone. So squad members may not hear these effects. Use headphones to avoid echo. Bluetooth mic latency/routing depends on the phone.",
            14, 0xFFFFD28A);
        warning.setPadding(4, 8, 4, 12);
        root.addView(warning, params(-1, -2));

        TextView footer = label("FFVB 2.0  •  ANDROID PROTOTYPE", 11, 0xFF8295A8);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer, params(-1, 38));
        setContentView(scroll);
    }

    private LinearLayout.LayoutParams params(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }
    private TextView label(String s, int size, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        return t;
    }
    private void section(LinearLayout root, String name) {
        TextView t = label(name, 13, 0xFF35D7FF);
        t.setPadding(4, 18, 4, 7);
        root.addView(t, params(-1, -2));
    }
    private void addButton(LinearLayout root, String name, int color, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(name); b.setTextColor(0xFFFFFFFF);
        b.setAllCaps(false);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));
        LinearLayout.LayoutParams p = params(-1, 54);
        p.setMargins(0, 5, 0, 5);
        root.addView(b, p);
        b.setOnClickListener(listener);
    }
    private void setStatus(String s, int color) {
        runOnUiThread(() -> { status.setText("● " + s); status.setTextColor(color); });
    }
    private boolean micPermission() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) return true;
        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 5);
        Toast.makeText(this, "Microphone permission allow karo, phir START dabao", Toast.LENGTH_LONG).show();
        return false;
    }
    private void setPitch(int rate, String name) {
        pitchRate = rate;
        if (micOn && monitorTrack != null) {
            try { monitorTrack.setPlaybackRate(rate); } catch (Exception ignored) {}
        }
        setStatus("VOICE PRESET: " + name, 0xFF75F0A8);
    }
    private void startMic() {
        if (micOn) return;
        if (!micPermission()) return;
        int min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        if (min <= 0) { setStatus("MIC NOT AVAILABLE", 0xFFFF7777); return; }
        try {
            recorder = new AudioRecord(MediaRecorder.AudioSource.MIC, RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 4);
            monitorTrack = new AudioTrack(AudioManager.STREAM_MUSIC, RATE,
                AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                min * 4, AudioTrack.MODE_STREAM);
            monitorTrack.setPlaybackRate(pitchRate);
            recorder.startRecording();
            monitorTrack.play();
            micOn = true;
            setStatus("MIC MONITOR ON — HEADPHONES USE KARO", 0xFF75F0A8);
            micThread = new Thread(() -> {
                short[] buf = new short[Math.max(512, min / 2)];
                while (micOn) {
                    int n = recorder.read(buf, 0, buf.length);
                    if (n > 0 && monitorTrack != null) monitorTrack.write(buf, 0, n);
                }
            }, "FFVB-Mic");
            micThread.start();
        } catch (Exception e) {
            stopMic();
            setStatus("AUDIO START ERROR", 0xFFFF7777);
        }
    }
    private void stopMic() {
        micOn = false;
        try { if (recorder != null) { recorder.stop(); recorder.release(); } } catch (Exception ignored) {}
        try { if (monitorTrack != null) { monitorTrack.stop(); monitorTrack.release(); } } catch (Exception ignored) {}
        recorder = null; monitorTrack = null;
        setStatus("READY", 0xFF75F0A8);
    }
    private void playToneSequence(int[] freqs, int durationMs) {
        stopEffect();
        new Thread(() -> {
            for (int f : freqs) {
                if (isFinishing()) return;
                int n = RATE * durationMs / 1000;
                short[] pcm = new short[n];
                for (int i = 0; i < n; i++)
                    pcm[i] = (short)(Math.sin(2 * Math.PI * f * i / RATE) * 8500);
                try {
                    effectTrack = new AudioTrack(AudioManager.STREAM_MUSIC, RATE,
                        AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                        n * 2, AudioTrack.MODE_STATIC);
                    effectTrack.write(pcm, 0, n);
                    effectTrack.play();
                    Thread.sleep(durationMs + 35);
                    stopEffect();
                } catch (Exception ignored) { stopEffect(); }
            }
            setStatus("SOUNDBOARD FINISHED", 0xFF75F0A8);
        }, "FFVB-Soundboard").start();
        setStatus("SOUNDBOARD PLAYING LOCALLY", 0xFFFFD28A);
    }
    private void stopEffect() {
        try { if (effectTrack != null) { effectTrack.stop(); effectTrack.release(); } } catch (Exception ignored) {}
        effectTrack = null;
    }
    @Override protected void onDestroy() {
        stopMic(); stopEffect(); super.onDestroy();
    }
}