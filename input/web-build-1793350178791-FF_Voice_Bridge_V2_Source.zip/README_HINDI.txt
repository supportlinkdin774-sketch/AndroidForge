FF VOICE BRIDGE 2.0 — AndroidIDE source prototype

INSTALL / BUILD:
1) ZIP extract karein.
2) AndroidIDE me extracted FF_Voice_Bridge_V2 folder ko Open Project karein.
3) Gradle sync complete hone dein (internet + Android SDK components required).
4) Build > Assemble/Build APK.
5) APK install karein; microphone permission allow karein.

FEATURES:
- Dark gaming-style interface
- Local microphone monitor
- Normal / Deep / High playback-rate voice presets
- Local soundboard test effects: Air Horn, Laser, Alert Beep
- Stop controls

LIMITS:
- Voice presets are simple playback-rate changes, not studio-grade voice conversion.
- Soundboard and mic monitor play locally on the phone/headphones.
- A normal Android app cannot generally replace/inject audio into Free Fire's microphone input. Therefore squad members hearing the effects is NOT supported or guaranteed by this app.
- Bluetooth headset routing and delay depend on Android/device firmware.
- This is source code, not a prebuilt/tested APK. Gradle/SDK versions may require build fixes.
